package com.rcraja.worldgate.network;

import com.google.gson.JsonObject;

import java.util.function.BiConsumer;

/**
 * Broadcasts a named emote to everyone in the room via /rooms/<code>/emotes.
 * Placeholder emote list for now -- RC RAJA is adding the real emote set
 * and animations later. This just wires up send/receive so that work
 * drops in without touching the networking layer again.
 */
public class EmoteManager {
    public static final String[] DEFAULT_EMOTES = { "wave", "dance", "sit", "cheer" };

    private final RoomChannel channel;

    public EmoteManager(FirebaseSession session) {
        this.channel = new RoomChannel(session, "emotes");
    }

    public void sendEmote(String roomCode, String emoteName) {
        JsonObject payload = new JsonObject();
        payload.addProperty("emote", emoteName);
        channel.send(roomCode, payload);
    }

    /** onEmote receives (senderUid, emoteName) for every new/existing broadcast. */
    public void listen(String roomCode, BiConsumer<String, String> onEmote) {
        channel.listen(roomCode, (uid, obj) ->
                onEmote.accept(uid, obj.has("emote") ? obj.get("emote").getAsString() : "?"));
    }

    public void stopListening() {
        channel.stopListening();
    }
}
